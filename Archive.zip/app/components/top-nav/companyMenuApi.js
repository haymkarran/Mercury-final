const CompanyMenuApi = [
    {
        id: 1,
        link: "/pages/company",
        title: "About Us",
        description: "Beyond Payments", 
    },
    {
        id: 2,
        link: "/pages/careers",
        title: "Join Us",
        description: "We build careers.", 
    },
    {
        id: 3,
        link: "/pages/contact-us",
        title: "Contact Us",
        description: "Write to us. Email us. See our location.", 
    },
];

export default CompanyMenuApi; 