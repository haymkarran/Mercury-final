const ResourcesHubMenuApi = [
    {
        "id": 1,
        "CatagoryTitle": "",
        "heroImageSrc": "",
        "heroContentLink": "", 
        "Contents": [
            { 
                "id": 1, 
                "imageSrc": "",
                "videoSrcImage": "",
                "imageAlt": "", 
                "titleText": "",
                "subText": "",
                "contentLink": "",
            },
        ],
    },
    
];

export default ResourcesHubMenuApi; 