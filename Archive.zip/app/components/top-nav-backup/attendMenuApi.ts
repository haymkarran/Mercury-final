const AttendMenuApi = [
    {
        id: 1,
        link: "/attend-singhular-talks",
        title: "Singhular Talks",
        description: "The special moment of pride you must experience.", 
    },
    {
        id: 2,
        link: "/attend-singhular-podcasts",
        title: "Singhular Podcasts",
        description: "Listen to Singhular podcasts 24/7 from anywhere.", 
    },
    {
        id: 3,
        link: "/attend-singhular-foodies",
        title: "Singhular Foodies",
        description: "Join the fun and frolic and pamper yourself with delicious food around you", 
    },
    {
        id: 4,
        link: "/attend-singhular-webinars",
        title: "Singhular Webinars",
        description: "Join Singhular webinars", 
    },
];

export default AttendMenuApi; 