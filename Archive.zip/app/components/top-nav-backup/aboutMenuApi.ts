const AboutMenuApi = [
    {
        "id": 1,
        "CatagoryTitle": "",
        "heroImageSrc": "",
        "heroContentLink": "",
        "Contents": [
            { 
                "id": 1, 
                "imageSrc": "",
                "titleText": "",
                "contentLink": "",
            },
        ],
    },
    {
        "id": 2,
        "CatagoryTitle": "",
        "heroImageSrc": "",
        "heroContentLink": "",
        "Contents": [
            { 
                "id": 1, 
                "imageSrc": "",
                "titleText": "",
                "contentLink": "",
            },
        ],
    },
];

export default AboutMenuApi; 